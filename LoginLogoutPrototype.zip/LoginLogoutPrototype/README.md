# Flask - Lab 3

This a snapshot of the state of Bookstore app - ready for deployment on OpenShift:

* The instructions on how to deploy on OpenShift are in a separate document.
* Make sure to rename run.py into wsgi.py
* You also need to supply the server with your MySQL credentials in \__init__.py
